using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace JetpackGame
{
    /*HOW TO MAKE A MENU
     * enum GameState
     * {
     * StartScreen,
     * LoadScreen,
     * Menu,
     * InGame
     * }
     */

    public class Game1 : Microsoft.Xna.Framework.Game
    {
        // declarations
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        KeyboardState oldKeyboard, newKeyboard;
        SpriteFont font;

        Player player;
        Rectangle barRectangle;
        Vector2 spawnPosition;
        Color statColor;

        List<Turret> turrets;
        
        /*List<Bullet> bullets, waitingBullets;
        int bulletDamage;
        float bulletFrequency, bulletSpeed;*/
        BulletService bulletService;
        BulletProperties[] bulletCatalog;

        List<StatCan> statCans;
        float spawnFrequency;
        Random random;
        
        Texture2D playerSprite, bulletSprite, bulletSpreadSprite, turretSprite, turretCaseLeftSprite, 
            turretCaseRightSprite, barSprite, plusSprite, header;
        Texture2D healthStat, fuelStat, healthRegenStat, fuelRegenStat, gravityStat,
            speedStat, repulsorStat;
        Texture2D[] statIcons;

        float fireTimer;
        float spawnTimer;
        float difficultyTimer, difficultyFactor;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            // set window preferences
            graphics.IsFullScreen = false;
            // graphics.PreferMultiSampling = true;
            // graphics.SynchronizeWithVerticalRetrace = true;
            graphics.PreferredBackBufferWidth = Helper.SCREEN_WIDTH;
            graphics.PreferredBackBufferHeight = Helper.SCREEN_HEIGHT;
        }

        protected override void Initialize()
        {
            LoadContent();

            //player
            spawnPosition = new Vector2((Helper.SCREEN_WIDTH - playerSprite.Width)/2f, Helper.SCREEN_HEIGHT - playerSprite.Height);
            player = new Player(100, 1500, spawnPosition, new Vector2(2.5f, 0.1f), playerSprite);

            //turrets
            turrets = new List<Turret>();
            turrets.Add(new Turret(player, turretSprite, new Vector2(0, Helper.SCREEN_HEIGHT), Helper.SCREEN_WIDTH, Helper.SCREEN_HEIGHT));
            turrets.Add(new Turret(player, turretSprite, new Vector2(Helper.SCREEN_WIDTH, Helper.SCREEN_HEIGHT), Helper.SCREEN_WIDTH, Helper.SCREEN_HEIGHT));

            //bullets
            /*bullets = new List<Bullet>(); waitingBullets = new List<Bullet>();
            bulletDamage = 10;
            bulletFrequency = 1.5f;
            bulletSpeed = 5f;*/

            //stat cans
            statCans = new List<StatCan>();
            spawnFrequency = 4f;
            random = new Random();
            statIcons = new Texture2D[7] { healthStat, fuelStat, healthRegenStat, fuelRegenStat, gravityStat, speedStat, repulsorStat };

            //timers
            fireTimer = 0; 
            spawnTimer = 0; 
            difficultyTimer = 0;
            difficultyFactor = 1;

            //bullet catalog
            bulletCatalog = new BulletProperties[]
            {
                new BulletProperties(Helper.BulletType.normal, Color.Black, bulletSprite, 10),
                new BulletProperties(Helper.BulletType.spread, Color.HotPink, bulletSpreadSprite, (int)(5)),
                new BulletProperties(Helper.BulletType.slow, Color.CornflowerBlue, bulletSpreadSprite, 10),
                new BulletProperties(Helper.BulletType.freeze, Color.PowderBlue, bulletSprite, 10),
                new BulletProperties(Helper.BulletType.teleport, Color.White, bulletSprite, 10)
            };

            //bulletService = new BulletService(ref player, bulletCatalog, ref turrets, ref difficultyFactor, graphics);
            bulletService = new BulletService(player, bulletCatalog, turrets, ref difficultyFactor);

            base.Initialize();
        }

        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            playerSprite = Content.Load<Texture2D>("player");
            turretSprite = Content.Load<Texture2D>("turret");
            bulletSprite = Content.Load<Texture2D>("bullet");
            bulletSpreadSprite = Content.Load<Texture2D>("bullet_spread");
            plusSprite = Content.Load<Texture2D>("plus");

            healthStat = Content.Load<Texture2D>("health");
            fuelStat = Content.Load<Texture2D>("fuel");
            healthRegenStat = Content.Load<Texture2D>("healthRegen");
            fuelRegenStat = Content.Load<Texture2D>("fuelRegen");
            gravityStat = Content.Load<Texture2D>("gravity");
            speedStat = Content.Load<Texture2D>("speed");
            repulsorStat = Content.Load<Texture2D>("repulsor");

            turretCaseLeftSprite = Content.Load<Texture2D>("turretcase_left");
            turretCaseRightSprite = Content.Load<Texture2D>("turretcase_right");

            barSprite = Content.Load<Texture2D>("horiz_bar");
            header = Content.Load<Texture2D>("headbar");

            font = Content.Load<SpriteFont>("myFont");
        }

        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            //difficultyTimer: scale up difficulty at fixed intervals
            difficultyTimer += (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (difficultyTimer > 20) //bump up difficulty every 20 seconds
            {
                difficultyFactor += 0.1f;
                difficultyTimer = 0;
            }

            //update player (movement and input)
            playerInput();
            player.Update(gameTime);

            //update turrets (movement)
            for (int i = 0; i < turrets.Count; i++)
            {
                turrets[i].Update();
            }

            bulletService.Update(gameTime);

            StatCanManager(gameTime);

            base.Update(gameTime);
        }

        public void playerInput()
        {
            newKeyboard = Keyboard.GetState();

            if (newKeyboard.IsKeyDown(Keys.Right)) // L-R movement
            {
                if (player.Position.X < Helper.SCREEN_WIDTH - player.Sprite.Width)
                    player.ChangePositionX(player.Velocity.X * player.GetAggregateMultiplier(Helper.StatIndex.speed));
            }
            else if (newKeyboard.IsKeyDown(Keys.Left))
            {
                if (player.Position.X > 0)
                    player.ChangePositionX(-player.Velocity.X * player.GetAggregateMultiplier(Helper.StatIndex.speed));
            }

            if (newKeyboard.IsKeyDown(Keys.Up) && player.CurrentFuel > 0) // jetpack is activated
            {
                if (oldKeyboard.IsKeyUp(Keys.Up)) // up was just pressed (wasn't down before)
                {
                    player.SetVelocityY(1.1f); // start a new upward acceleration
                }

                player.CurrentFuel -= 1;

                if (player.Position.Y > header.Height) // motion
                {
                    if (player.Velocity.Y < 4f) { player.Accelerate(0.05f * 
                        player.GetAggregateMultiplier(Helper.StatIndex.speed)); } // accelerate at 5%
                    player.ChangePositionY(-player.Velocity.Y);
                }
            }
            else if (player.Position.Y < Helper.SCREEN_HEIGHT - player.Sprite.Height)
            {
                if (oldKeyboard.IsKeyDown(Keys.Up)) // up was just released
                {
                    player.SetVelocityY(1.1f);
                }

                player.Accelerate(0.12f); // accelerate at 20%
                player.ChangePositionY(player.Velocity.Y);
            }

            // TODO: pause key

            // TODO: menu key

            oldKeyboard = newKeyboard;
        }

        public void StatCanManager(GameTime gameTime)
        {
            //spawnTimer: create stat cans
            spawnTimer += (float)gameTime.ElapsedGameTime.TotalSeconds;

            int randX, randY, randStatChance;
            if (spawnTimer > (spawnFrequency / difficultyFactor))
            {
                randX = random.Next(20, Helper.SCREEN_WIDTH - plusSprite.Width - 20);
                randY = random.Next(20, 250);
                randStatChance = random.Next(1, 20);

                if (randStatChance <= 8) // 40% health
                {
                    statCans.Add(new StatCan(new Vector2(randX, randY), plusSprite, 10 * difficultyFactor, Helper.StatIndex.health));
                }
                else if (randStatChance > 8 && randStatChance < 16) // 35% fuel
                {
                    statCans.Add(new StatCan(new Vector2(randX, randY), plusSprite, 150 * difficultyFactor, Helper.StatIndex.fuel));
                }
                else
                {
                    switch (randStatChance) // 5% for each of the multipliers
                    {
                        case 16:
                            statCans.Add(new StatCan(new Vector2(randX, randY), plusSprite, 1.25f, Helper.StatIndex.healthRegen));
                            break;
                        case 17:
                            break;
                        case 18:
                            break;
                        case 19:
                            break;
                        case 20:
                            break;
                        default:
                            break;
                    }
                }

                spawnTimer = 0;
            }

            //update stat cans (collision)
            foreach (StatCan statCan in statCans)
            {
                if (statCan.Enabled && statCan.Hitbox.Intersects(player.Hitbox))
                {
                    switch (statCan.Stat)
                    {
                        case Helper.StatIndex.health: //health
                            player.CurrentHealth += (int)statCan.Value;

                            if (player.CurrentHealth > player.MaxHealth) //check for overflow
                                player.CurrentHealth = player.MaxHealth;

                            break;
                        
                        case Helper.StatIndex.fuel:
                            player.CurrentFuel += (int)statCan.Value;

                            if (player.CurrentFuel > player.MaxFuel) //check for overflow
                              player.CurrentFuel = player.MaxFuel;
                            break;

                        case Helper.StatIndex.healthRegen:
                            break;

                        case Helper.StatIndex.fuelRegen:
                            break;

                        case Helper.StatIndex.gravity:
                            break;

                        case Helper.StatIndex.speed:
                            break;

                        case Helper.StatIndex.repulsor:
                            break;

                        default:
                            break;
                    }

                    statCan.Enabled = false;
                }
            }
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.WhiteSmoke);

            spriteBatch.Begin();
            
            // draw player with texture and position
            player.Draw(spriteBatch);

            // draw turret with texture, position, rotation, origin, and layerDepth
            for (int i = 0; i < turrets.Count; i++)
            {
                turrets[i].Draw(spriteBatch);
            }

            // draw bullets with texture and position, or delete them
            bulletService.Draw(spriteBatch);

            // draw stat cans with texture and position, or delete them
            for (int i = 0; i < statCans.Count; i++)
            {
                if (statCans[i].Enabled)
                {
                    statCans[i].Draw(spriteBatch);
                }
                else
                {
                    statCans.RemoveAt(i);
                    i--;
                }
            }

            //header (health/fuel bars, score, and more?)
            spriteBatch.Draw(header, new Vector2(0, 0), Color.White);

            barRectangle = new Rectangle(25, 8, (int)(barSprite.Width * player.HealthPercentage()), barSprite.Height);
            spriteBatch.Draw(barSprite, barRectangle, Color.Chartreuse); //25, 8

            barRectangle = new Rectangle(25, 22, (int)(barSprite.Width * player.FuelPercentage()), barSprite.Height);
            spriteBatch.Draw(barSprite, barRectangle, Color.Gold); //25, 22

            spriteBatch.DrawString(font, Convert.ToString(Math.Round((decimal)(gameTime.TotalGameTime.TotalMilliseconds/100), 0)), 
                new Vector2(440, 9), Color.White); //437, 8
            
            //slots: 541, 577, 613, 649, 685, 721, 757 (y = 8 for all)

            for (int i = 0; i < statIcons.Length; i++)
            {
                if (player.GetAggregateMultiplier((Helper.StatIndex)i) > 1) //you can actually cast an int to an enum!  phew...
                    statColor = Color.White;
                else if (player.GetAggregateMultiplier((Helper.StatIndex)i) < 1)
                    statColor = Color.Red;
                else
                    statColor = Color.LightGray;

                spriteBatch.Draw(statIcons[i], new Vector2(541 + 36*i, 8), statColor);
            }
            
            // eye candy for the turrets
            spriteBatch.Draw(turretCaseLeftSprite, new Vector2(0, Helper.SCREEN_HEIGHT - turretCaseLeftSprite.Height), Color.White);
            spriteBatch.Draw(turretCaseRightSprite, new Vector2(Helper.SCREEN_WIDTH - turretCaseRightSprite.Width, Helper.SCREEN_HEIGHT - turretCaseRightSprite.Height), Color.White);

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
